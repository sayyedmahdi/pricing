$(function(){
	
    $(".datepicker-input").map(function() {
        $(('#'+this.dataset.text_selector)).MdPersianDateTimePicker({
            targetTextSelector: ('#'+this.dataset.text_selector),
            targetDateSelector: ('#'+this.dataset.data_selector),
            //selectedDate: new Date(),
            dateFormat: 'yyyy-MM-dd',
            isGregorian: false
        });
    })
	
});