$(function(){
	$(".select2-select,.select2-multiple-select").select2();	// {allow_single_deselect:true}
});