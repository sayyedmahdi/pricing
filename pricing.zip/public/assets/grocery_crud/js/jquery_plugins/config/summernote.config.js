// Added by CI Bootstrap 3
$(function(){
	$('textarea.texteditor').summernote({
		height: 200
	});
	$('textarea.mini-texteditor').summernote({
		height: 200
	});
});