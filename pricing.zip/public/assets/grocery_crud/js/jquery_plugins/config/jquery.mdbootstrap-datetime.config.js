  $(function(){
    /*$(".fc-datepicker").map(function() {
        $(('#'+this.dataset.text_selector)).datepicker({
            // targetTextSelector: ('#'+this.dataset.text_selector),
            // targetDateSelector: ('#'+this.dataset.data_selector),
            altField: ('#'+this.dataset.data_selector),
            //selectedDate: new Date(),
            dateFormat: 'yy-mm-dd ',
            isGregorian: false,
            enableTimePicker: true
        });
    })*/
      $('.fc-datepicker').datepicker({
          dateFormat: 'yy-mm-dd',
          showButtonPanel: true,
          changeMonth: true,
          changeYear: true
      });

  });
