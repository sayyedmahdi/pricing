﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/

CKEDITOR.plugins.setLang('placeholder','it',{placeholder:{title:'Proprietà segnaposto',toolbar:'Crea segnaposto',text:'Testo segnaposto',edit:'Modifica segnaposto',textMissing:'Il segnaposto deve contenere del testo.'}});
