<?php

return [
    'api_key'  => env('IPPANEL_API', 'Default'),                      
];